<?php require 'header.php' ?>

    <!-- Navigator Start -->
    <div id="navigator">
        <div class="container">
            <div class="path">
                <div class="path-main" style="color: darkred; display:inline-block;">Home</div>
                <div class="path-directio" style="color: grey; display:inline-block;"> / Login</div>
            </div>

        </div>
</div>
    <!-- Navigator End -->

    <!-- Login Start -->
    <div id="login">
        <div class="container">
                <img src="imgs/logo.png" alt="">
                <form method="post">
                    <input class="username" type="email" placeholder="Registered Email" name="email" value="<?php
                                if(isset($_COOKIE['uemail']))
                                { echo $_COOKIE['uemail'];}
                                ?>" required>
                    <input class="password" type="Password" placeholder="Password" name="password" value="<?php
                                if(isset($_COOKIE['upass']))
                                { echo $_COOKIE['upass'];}
                                
                                ?>" required>
                    <input class="check" type="checkbox" name="chk">Remember me
                    <a href="#">Forget Password ?</a><br>
                    <div class="reg-group">
                        <button style="background-color: darkred;">Login</button>
                        <button style="background-color: rgb(51, 58, 65);">Make new account</button>
                    </div>
                </form>
        </div>
</div>
    <!-- Login End -->

    <?php require 'footer.php' ?>
<?php require 'header.php' ?>

    <!-- Navigator Start -->
    <section id="navigator">
        <div class="container">
            <div class="path">
                <div class="path-main" style="color: darkred; display:inline-block;">Home</div>
                <div class="path-directio" style="color: grey; display:inline-block;"> / Sign up</div>
            </div>

        </div>
    </section>
    <!-- Navigator End -->

    <!-- Sign Up Start -->
    <section id="sign-up">
        <div class="container">
                <img src="imgs/logo.png" alt="">
                <form action="submit">
                    <input type="name" placeholder="Name" required>
                    <input type="email" placeholder="Email" required>
                    <input type="date" name="bday" placeholder="Birth date">
                    <select name="gender" id="type" required>
                        <option value="Not" name="gender" disabled>Gender</option>
                        <option value="Male" name="gender">Male</option>
                        <option value="Female" name="gender">Female</option>
                        <option value="Other" name="gender">Other</option>
                    </select>
                    <select name="type" id="type" required="">
                        <option value="Blood Type" name="blood_group" disabled>Blood Type</option>
                        <option value="A" name="blood_group">A</option>
                        <option value="B" name="blood_group">B</option>
                        <option value="O" name="blood_group">O</option>
                        <option value="AB+" name="blood_group">AB+</option>
                    </select>
                    <input type="text" placeholder="Address" name="address">
                    <input type="Phone" placeholder="Phone Number" required="">
                    <div class="reg-group">
                        <input class="check" type="checkbox" required="" style="height: auto; display:inline; margin: 0 auto;">Agree on terms and conditions<br>
                        <button class="submit" type="submit" style="background-color: rgb(51, 58, 65);">Submit</button>
                    </div>
                </form>
        </div>
    </section>
    <!-- Sign Up End -->

    <?php require 'footer.php' ?>
<?php 

require "model.php";
class Control extends Model
{
    function __construct()
    {
        Model::__construct();
        $url = $_SERVER['PATH_INFO'];
        switch($url)
        {
            case "/index":
                include "index.php";
                break;
                case "/dashboard":

                  $user_arr = $this->select('users');
                    include "dashboard.php";
                    break;
                    case "/add-user":
                        if(isset($_POST['register']))
                        {
                            $name = $_POST['name'];
                            $email = $_POST['email'];
                            $password = $_POST['password'];
                            
                            $mobile = $_POST['mobile'];
                            $address = $_POST['address'];
                            $gender = $_POST['gender'];
                            $chk = $_POST['chk'];

                            $language = "";

                            foreach($chk as $lang)
                            {
                                $language = $language . $lang.",";
                            }
                            $image = $_FILES['file']['name'];
                            $dup_image = $_FILES['file']['tmp_name'];
                            $path = 'assets/images/'.$image;

                            move_uploaded_file($dup_image,$path);


                            $data = array("name"=>$name,"email"=>$email,"password"=>$password,"mobile"=>$mobile,"address"=>$address,"gender"=>$gender,"languages"=>$language,"image"=>$image);

                           $insert = $this->insert("users",$data);
                           if($insert)
                           {
                            echo "<script> alert('Record Inserted..!')</script>";
                           }


                        }
                        
                        include "add-user.php";
                        break;

                        case "/view-user":
                            $vId = $_REQUEST['vId'];

                            echo $vId;//45 46 47 

                            $where = array('id'=>$vId);

                           $run =  $this->select_where('users',$where);
                           $fetch = $run->fetch_object(); 

                         
                        
                            include "view-user.php";
                            break;


                            case "/edit-user":

                                    $eid = $_REQUEST['eId'];

                                    $where = array('id'=>$eid);

                                  $run = $this->select_where('users',$where);
                                  $fetch = $run->fetch_object();

                                    // select_where($tbl,$where)


                                if(isset($_POST['register']))
                                {
                                    $name = $_POST['name'];
                                    $email = $_POST['email'];
                                    $password = $_POST['password'];
                                    
                                    $mobile = $_POST['mobile'];
                                    $address = $_POST['address'];
                                    $gender = $_POST['gender'];
                                    $chk = $_POST['chk'];
        
                                    $language = "";
        
                                    foreach($chk as $lang)
                                    {
                                        $language = $language . $lang.",";
                                    }
                                    $image = $_FILES['file']['name'];
                                    $dup_image = $_FILES['file']['tmp_name'];
                                    $path = 'assets/images/'.$image;
        
                                    move_uploaded_file($dup_image,$path);
        
        
                                    $data = array("name"=>$name,"email"=>$email,"password"=>$password,"mobile"=>$mobile,"address"=>$address,"gender"=>$gender,"languages"=>$language,"image"=>$image);
        
                                   $update = $this->update("users",$data,$where);
                                   if($update)
                                   {
                                    echo "<script> alert('Record updated..!')</script>";
                                   }
        
        
                                }
                                include "edit-user.php";
                                break;

                                case "/delete-user":
                                    $delid = $_REQUEST['delId'];

                                    $where = array('id'=>$delid);

                                     $delete = $this->delete_where('users',$where);

                                     if($delete)
                                     {
                                        header("location:dashboard");
                                     }
                                    //  include "dashboard.php";
                                    break;

        }
    }
}

$obj = new Control(); 
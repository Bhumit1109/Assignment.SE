<?php include 'header.php' ?>

<div class="container-xxl contact py-5">
        <div class="container">
           
          
            <div class="row justify-content-center g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h3 class="mb-4">Already a member? </h3>
                    <p class="mb-4"> <a href="index">Please Login</a>.</p>
                    <form  method="post" enctype="multipart/form-data">
                        <div class="row g-3">

                        <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  name="name" placeholder="Your Name" id="uname" value="<?php   echo $fetch->id;?>" disabled>
                                    <label for="name">ID</label>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  name="name" placeholder="Your Name" id="uname" value="<?php   echo $fetch->name;?>">
                                    <label for="name">Name</label>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  name="email" placeholder="Your Email" id="uemail" value="<?php   echo $fetch->email;?>">
                                    <label for="email">Email</label>
                                </div>
                            </div>
                           
                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  
                                    name="password" placeholder="Your Password" id="upass" value="<?php   echo $fetch->password?>">
                                    <label for="password" >Password</label>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"   name="cpassword" placeholder="Confirm Password" id="ucpass">
                                    <label for="cpass" >Confirm Password</label>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"   name="mobile" placeholder="Your Mobile"  id="umobile" value="<?php   echo $fetch->mobile;?>">
                                    <label for="mobile">Mobile</label>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"   name="address" placeholder="Your Address" id="uaddress" value="<?php   echo $fetch->address;?>">
                                    <label for="adrs">Address</label>
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="border py-3 ps-3">
                                <label for="gender">Gender</label>
                                    <input type="radio" name="gender" value="male" 
                                   <?php
                                   
                                   if($fetch->gender == "male")
                                   {
                                       echo "checked";
                                   }?>
                                    
                                    > Male
                                    <input type="radio" name="gender" value="female"
                                    <?php
                                   
                                   if($fetch->gender == "female")
                                   {
                                       echo "checked";
                                   }?>
                                    
                                    > Female
                                    
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="border py-3 ps-3">
                                <label for="Lang">Languages</label>
                                    <input class="x" type="checkbox" name="chk[]" value="Gujarati"> Gujarati
                                    <input type="checkbox" name="chk[]"  class="x" value="Hindi"> Hindi
                                </div>
                            </div>

                            
  <script>
    lang_arr = document.getElementsByClassName('x')

    console.log(lang_arr[0].checked)
  </script>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="file" class="form-control"   name="file" id="uimage" >
                                    <label for="img">Upload Image</label>

                                    <img src="assets/images/<?php echo $fetch->image?>" alt="NO Image" height="100">
                                </div>
                            </div>

                            <div class="col-md-12">
                                <div class="form-floating">
                                    <input type="submit"  name="register" class="btn btn-primary" id="btn">
                                    
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
              
            </div>
        </div>
    </div>

<?php include 'footer.php' ?>
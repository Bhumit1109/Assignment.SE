<?php include 'header.php' ?>

<div class="container-xxl contact py-5">
        <div class="container">
           
          
            <div class="row justify-content-center g-5">
                <div class="col-lg-6 wow fadeInUp" data-wow-delay="0.1s">
                    <h3 class="mb-4">Users Details </h3>
                    <p class="mb-4"> <a href="dashboard">Go back</a>.</p>
                 
                    <h3><?php   echo $fetch->name;?></h3>
                </div>
              
            </div>
        </div>
    </div>

<?php include 'footer.php' ?>